# Unit 020 — independent mathematical and structural review

Date: 2026-08-23

## Review scope

The review independently reread `source/id-ID/units/unit-020-lecture-020.md`
against Roberts `Notes.tex:3948–4345` at the frozen upstream commit
`b947ad2e9f9e301bfe24590a9db653bc54fa1a53`. It checked the source boundary,
all source structures and semantic figures, stable IDs, the six mastery
triples, the graph/coboundary matrices, the tetrahedron and Klein-bottle
Smith calculations, the cohomology-functor proof, Indonesian terminology, and
Pandoc structural parsing.

## Final snapshot and verdict

Final snapshot: **45,786 bytes, 1,425 LF lines, SHA-256
`ed086dfe2f26951d4a1d1c398ade0224ffbf4bd1a20a985d267ecd97bbd228d3`**.

- P1: 0
- P2: 0
- P3: 0
- Source span and deferred Lecture 21 boundary are exact.
- All 73 declared structural IDs are unique and remain in the `o012-rbt-l20`
  namespace; all seven semantic figures, eleven margins, eight source-audit
  records, and the 6×(problem/hint/solution) closure are present.
- The triangle transpose/sign convention, graph kernel/cokernel, the
  `delta_1 delta_0=0` proof, tetrahedron cohomology, and Klein-bottle Smith
  form were recomputed. In particular, the Klein cokernel is `Z/2`, not a
  free-plus-torsion group.
- The face-identity proof is retained as the complete Unit 20 lemma; the
  mastery set tests its consequences through the torus, tetrahedron, and
  functoriality checks rather than duplicating that proof as a seventh item.
- The same-field terminology QA is applied: `fungtor`, `morfisma`,
  `homomorfisma`, `isomorfisma`, `lembaran`, and `tertutup rata`; no
  `isomorfisme` spelling remains in reader-facing text.
- The final language pass corrected the isolated nonstandard spelling
  `bertelescop` to `berteleskop` without changing mathematics or identifiers.
- Pandoc 3.9.0.2 `--to=html5 --mathjax` exits 0 without warnings, and all
  structural IDs survive the parse.
- The two proof closures at source-derived lines 737 and 923 are explicitly
  delimited as `$\\square$`, eliminating the stray-math-delimiter failure
  found by the cumulative PDF gate.
- The mastery hint at line 976 uses LaTeX `\\delta` rather than a literal
  Unicode Greek character, keeping the source portable to pdflatex.

## Attribution and process transparency

The unit retains Roberts's source credit, CC BY 4.0, the independent/non-
endorsement statement, and the exact process note **OpenAI Codex gpt-5.6-sol,
Ultra**. No upstream contact or publication was performed as part of this
review. Unit 20 passes the independent-review gate, subject to the cumulative
build/backend gates before admission.
