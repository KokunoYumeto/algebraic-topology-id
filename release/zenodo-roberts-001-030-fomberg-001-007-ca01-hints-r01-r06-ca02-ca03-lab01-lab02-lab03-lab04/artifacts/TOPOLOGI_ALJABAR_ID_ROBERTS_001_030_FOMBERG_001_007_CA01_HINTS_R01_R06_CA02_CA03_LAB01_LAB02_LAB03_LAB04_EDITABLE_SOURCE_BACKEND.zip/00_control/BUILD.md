# Build record

## Roberts 001–030 + Fomberg 001–007 + CA01 + hints R01–R06 + CA02–CA03 + Labs 1–3 — finalized local boundary

Builder:
`scripts/build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03-lab01-lab02-lab03.py`.
Finalizer:
`scripts/finalize-build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03-lab01-lab02-lab03.py`.
The builder preserves the complete 529-page Lab 2 predecessor, performs two
clean deterministic HTML/appendix-PDF/merged-PDF writes, adds 25 stable IDs,
18 headings, and six solved tasks, and rejects unresolved include markers.
The finalizer binds source/execution review, the exact 7,694-record append-only
backend, visual/browser QA, embedded/subset/ToUnicode fonts, links, MathML,
rights, privacy, and final artifact identities.

```powershell
python -B scripts/build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03-lab01-lab02-lab03.py
python -B scripts/finalize-build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03-lab01-lab02-lab03.py
```

- HTML: 15,828,588 bytes/SHA-256
  `c221955503cec820c7581c740a038ac1774999ac6a6014f8d0783da2cd08bf0d`.
- PDF: 9,836,725 bytes/545 A4 pages/SHA-256
  `b26b670db97facc9f5ab389eed69cf1f8b03f70e6047eacbd2bfa68c849ccd0d`.
- Manifest: 381 bytes/SHA-256
  `29b27f5dac78797428539e0941f75f4c27362ab8efcd0149b2e803ed9c5c63c0`.
- Final build receipt: 7,575 bytes/SHA-256
  `18cbb0558a08cee737e375351a4f3f7fb7b65c0e29672b22851612a8a58d1eab`.
- Visual QA: pages 529–545, 17 RGB renders at 160 dpi, P1/P2/P3 zero;
  receipt SHA-256
  `43cccd44fc3cbfcf3b01542a32776dfbd37788bd011cd77115ed711bbbc934ba`.
- Browser QA: desktop/mobile PASS, 4 code and 3 math local scrollers, 2,242
  resolved fragments, 17,386 MathML nodes, zero external runtime assets,
  zero console errors/warnings, P1/P2/P3 zero; receipt SHA-256
  `194f6da23dc3f299a8da8c3fc6cfa71f72de5ee202a82cce4a1b9bd460cca070`.
- PDF remains untagged; the self-contained native-MathML HTML is the primary
  reflowable and accessibility-oriented surface.

Zenodo version `0.31.5`, record `22151513`, DOI
`10.5281/zenodo.22151513`, is public in concept
`10.5281/zenodo.22061489`. The exact nine-file reader-first package passed two
complete anonymous HTTP 200 byte/SHA-256 readback passes. Sanitized publication
receipt is 11,691 bytes/SHA-256
`7fbf0e059ce9fdba120fc953a27ea2fcba4419420a94ea9e754ffe4b8741ed46`;
transaction receipt is 980 bytes/SHA-256
`b6704000dda644f677af833a3a0abe6f9490061e08aad9ec0d28e1c673568fb9`.
GitHub/Pages integration is the remaining public action for this boundary.

## Roberts 001–030 + Fomberg 001–007 + CA01 + hints R01–R06 + CA02–CA03 — prior published boundary

Builder:
`scripts/build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03.ps1`.
It preserves the complete 482-page predecessor by semantic and 72-dpi RGB
pixel equivalence, renders CA02/CA03 twice from clean bounded scratch, and
requires byte-identical HTML/PDF output, 68 new stable destinations, exact
assessment QA, the append-only backend prefix, embedded/subset/ToUnicode fonts,
links, MathML, rights, privacy, and artifact identities.

```powershell
python -B scripts/qa-cumulative-assessments-002-003.py
python -B scripts/validate-backend-append-only-cumulative-assessments-002-003.py
pwsh -NoProfile -File scripts/build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03.ps1
python -B scripts/finalize-build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03.py
```

- CA02: 25,321 bytes/SHA-256
  `2f8dc58eb4fb2da06e239d8e0979112c5f50c846f584900a2e7ea4999a8685ea`.
- CA03: 26,074 bytes/SHA-256
  `35c2c9a1b7edbeb1902245b567754e33f4720e11b48d2822bad7666a6a626894`.
- HTML: 15,287,428 bytes/SHA-256
  `417e50656ae0a61134c480f59df1bcd54d66a68c938d1d54f9c931ba37e2a5d6`.
- PDF: 8,915,996 bytes/501 A4 pages/SHA-256
  `74ed9b5bf0f79a98693369dc7beba3e84ac81c711cc96b9951ae950ae9632a16`.
- Manifest: 345 bytes/SHA-256
  `40220aec7c99f28892775a2d274bcc24ae3cc847946737424a254d97aa7f5c69`.
- Final build receipt: 81,018 bytes/SHA-256
  `596f0e89e8c4abe310019dca95f0e457e7b70983f490afba26291211af0f55b9`.
- Backend: 7,273 records/8,840,132 bytes/bundle SHA-256
  `97edc6371a0bf670ebdaaa4fab8618ec138ae25c4bf54ca9172139934ba0b464`.

The serialized HTML has 2,466 unique IDs, 516 resolving fragment links, and
16,911 native MathML nodes. Browser QA passes at 1,440×900 and 375×812 with a
centered reading column, zero page-level overflow, zero external assets, and
only intentional formula-local mobile scrollers. PDF pages 482–501 all pass
original-detail visual inspection and structural glyph-bound checks; all 20
are A4 and nonempty, with zero replacement/square markers and zero out-of-page
glyph boxes. P1/P2/P3 are zero. The PDF remains disclosed as untagged.

Zenodo version `0.31.2`, record `22135136`, DOI
`10.5281/zenodo.22135136`, preserves the reader-first nine-file package in the
existing concept `10.5281/zenodo.22061489`. Every file passed two anonymous
HTTP 200 byte/SHA-256 readback passes. Sanitized publication receipt SHA-256:
`d097cabe1c857b498ec0bf1dcca620e6cd957797ab70777ba229b6c3540a2871`.
GitHub content commit `657f21813ef39bd9e86558a2f4e16e79c23ce491`, tree
`2d7da6665cabbfe9ea8a0157cd533b53ff053b5c`, Pages run `33129294989`, job
`98714787548`, deployment `6133283357`, and deployment status `17437766400`
all pass. Anonymous codeload verification matched all 66 changed files
(65,610,666 bytes) with zero removals or mismatches and delta-manifest SHA-256
`0df36a710e29600baa2978d99b60db030559e01bfc67d1f92951e491ffa2af94`.
The commit-pinned raw reader and deployed Pages reader match the HTML bytes
exactly; the 0.31.1 predecessor remains byte-identical. GitHub publication
receipt is 27,588 bytes/SHA-256
`b06804594412a9de0953120478ca8cf2d2e1c0f09f68cbce706e0930c02f2e6b`.

## Roberts 001–030 plus Fomberg 001–007 — prior boundary

Builder: `scripts/build-roberts-001-030-fomberg-001-007.ps1`. It freezes the
complete Roberts component and Fomberg `algebraic_topology.tex:31–4185`, builds
HTML and PDF twice from clean task-local scratch, requires byte identity, and
fails closed on authority, cursor, semantic structure, links, MathML, figures,
rights, privacy, fonts, images, trailer IDs, backend replay, or artifact hashes.

```powershell
python -B scripts/qa-fomberg-unit-007.py
python -B scripts/validate-backend-append-only-fomberg-unit-007.py
python -B scripts/validate-backend-append-only-fomberg-unit-007-cumulative.py
pwsh -NoProfile -File scripts/build-roberts-001-030-fomberg-001-007.ps1
python -B scripts/finalize-build-roberts-001-030-fomberg-001-007.py
```

- Unit reader: 60,598 bytes/1,934 LF lines/72 stable IDs; SHA-256
  `417b62c6c334b2f55965b623d8bfc8c3c94d4b2e109db149e42e294916673def`.
- HTML: `output/html/roberts-001-030-fomberg-001-007/index.html`, 14,885,069
  bytes; SHA-256
  `87d58a5955954125c424ab1220a9c6aa7967a782a9bd739094a31ae0a50af5f6`.
- PDF: `output/pdf/topologi-aljabar-roberts-001-030-fomberg-001-007-id.pdf`,
  8,326,404 bytes/472 A4 pages; SHA-256
  `1beca2d03f04c1fcca7eb01bd2654567908febc1ba7941b459c06b90ef865c22`.
- Manifest: `output/ARTIFACT_MANIFEST_ROBERTS_001_030_FOMBERG_001_007.csv`,
  287 bytes; SHA-256
  `6a5a49c1a7179c27bb21f9bced2517ff38cf79953d566f75eb3143b6a3039aaa`.
- Build receipt: `qa/ROBERTS_001_030_FOMBERG_001_007_BUILD_RECEIPT.json`,
  7,042 bytes; SHA-256
  `bef3d7fbd0aa1290a34f6a942c0559130fd5b32a66531afb7f56d91cb148cc8e`.
- Append-only backend: 6,742 records/8,213,649 bytes; validator-defined bundle
  SHA-256 `523b570517eb54720c50007aacc5d4eea525ea252b9ca1f6f45b027182354765`.

The HTML is self-contained with 440 resolved fragments, 15,945 native MathML
nodes, 159 semantic figures, and 19 embedded PNGs. Local in-app-browser QA
passes at 1,440×900 and 375×812 with centered/reflowing layout and zero
page-level overflow; console errors are zero (two non-fatal instrumentation
warnings). PDF pages 438–472 were rendered and inspected with no clipping,
overlap, margin collision, or unreadable glyph; the PDF remains disclosed as
untagged. Two clean builds of each surface are byte-identical. The next source
cursor is Fomberg line 4186; the selected external span is exhausted.

Zenodo version `0.30.7`, record `22104150`, DOI
`10.5281/zenodo.22104150`, preserves this reader-first nine-file package in
the existing concept `10.5281/zenodo.22061489`. Every public file was read
back anonymously and matches the local byte count and SHA-256. Publication
receipt SHA-256:
`3145ad59d3eae2935319e502b30e30fe62c31b1d7eaebab087b5f24b220f874f`.

GitHub commit `1c25c0b43ba605ff16cf95363f405455f78f29eb`, tree
`814d6d5a8ea5164928709a60e16ee13946970f52`, Pages run `32919363394`, job
`98029663052`, deployment `6095315253`, and status `17336537558` succeeded.
The public Pages HTML and nine commit-pinned source/release witnesses match
local bytes. Receipt SHA-256:
`51eb8da851deb5aa6aba12b6655e16a54e321811b543e34c772bfa11fdb3fa98`.

## Roberts 001–030 plus Fomberg 001–006 — prior boundary

Builder: `scripts/build-roberts-001-030-fomberg-001-006.ps1`. It freezes the
complete Roberts component and Fomberg `algebraic_topology.tex:31–3517`, builds
HTML and PDF twice from clean task-local scratch, requires byte identity, and
fails closed on authority, prior-boundary drift, semantic structure, links,
MathML, figures, rights, privacy, fonts, images, trailer IDs, backend replay,
or artifact hashes.

```powershell
python -B scripts/qa-fomberg-unit-006.py
python -B scripts/validate-backend-append-only-fomberg-unit-006.py
python -B scripts/validate-backend-append-only-fomberg-unit-006-cumulative.py
pwsh -NoProfile -File scripts/build-roberts-001-030-fomberg-001-006.ps1
python -B scripts/finalize-build-roberts-001-030-fomberg-001-006.py
```

- Unit reader: 41,416 bytes/1,053 LF lines/55 stable IDs; SHA-256
  `e8d4d5391f8cdf4e62a019f7a991d09e4b610633e8e660dec4e0ea2b61c538f7`.
- HTML: `output/html/roberts-001-030-fomberg-001-006/index.html`, 12,555,960
  bytes; SHA-256
  `80a7d092cb786e4d4f7ecab31ba40746cf59398db50f0adca50f2431746f7c92`.
- PDF: `output/pdf/topologi-aljabar-roberts-001-030-fomberg-001-006-id.pdf`,
  6,723,586 bytes/452 A4 pages; SHA-256
  `136dc7f6fa744e87fe067a96a36a8fbee8098aad9167629653bc085f6a718c37`.
- Manifest: 287 bytes; SHA-256
  `a6a507bb89af051904d54629738f9f9c355eeadade5bf6c1a7d62ad48bd0858c`.
- Build receipt: `qa/ROBERTS_001_030_FOMBERG_001_006_BUILD_RECEIPT.json`,
  10,169 bytes; SHA-256
  `0347abd8312f8058a769a2b0b01c4d3605798c544c832e0fff82d84ade912829`.
- Append-only backend: 6,512 records/7,855,910 bytes; validator-defined bundle
  SHA-256
  `377be644a38e6db06f8992113ea47b8fc172953254c9b1005493e0ad3b7bd4ad`.

The final HTML contains 2,231 reader ID attributes after excluding the browser
QA overlay, 431/431 resolved fragments, 15,273 native MathML nodes, and 142
semantic figures. Browser QA confirms a centered 1,152-pixel body at
1,440 × 900 and a 360/360-pixel body and document at 375 × 812 with zero
page-level overflow; 427 intentionally wide formulas/tables scroll only inside
their local containers. PDF pages 438–452 were rendered and inspected; all 27
fonts are embedded/subset/ToUnicode. The PDF remains disclosed as untagged.

GitHub release commit `372f9d01d691393760779dc840b6d8c36ea2b025`, Pages
run `32906265163`, job `97990960689`, deployment `6093297209`, and deployment
status `17329343917` succeeded, and the public HTML plus nine commit-pinned
witnesses match local bytes.
Zenodo version `0.30.6`, record `22102865`, DOI
`10.5281/zenodo.22102865`, preserves the reader-first nine-file package in the
existing concept; every file was anonymously read back with its exact local
SHA-256. This is the historical Unit 006 boundary; the current Unit 007
boundary is documented above and the next source cursor is line 4186.

## Roberts 001–030 plus Fomberg 001–004 — prior boundary

Builder: `scripts/build-roberts-001-030-fomberg-001-004.ps1`. It freezes the
complete Roberts component and Fomberg `algebraic_topology.tex:31–2846`, builds
HTML and PDF twice from clean scratch per invocation, requires byte identity,
and fails closed on authority, cursor, semantic structure, links, MathML,
figures, rights, privacy, fonts, images, trailer IDs, or protected prior output
drift. A third complete invocation reproduced the same bytes.

- HTML: `output/html/roberts-001-030-fomberg-001-004/index.html`, 8,155,605
  bytes, SHA-256
  `cd620d5557ff05fb81fb9cf044e8bd4848a6f92ef8fcd06078b8a124f6e79326`.
- PDF: `output/pdf/topologi-aljabar-roberts-001-030-fomberg-001-004-id.pdf`,
  3,964,018 bytes, 424 A4 pages, SHA-256
  `bbe4b2392991ace6922230374833bf0982e00a8b6d2fddb94a990b663c8440bf`.
- Manifest: 286 bytes, SHA-256
  `40e68a9f79e63a7dc6f6d769aa2ab8441e014f5eb9ccf157151c5a2d7aae5bee`.
- Build receipt: `qa/ROBERTS_001_030_FOMBERG_001_004_BUILD_RECEIPT.json`,
  10,029 bytes, SHA-256
  `d59e54ab6b9d370a8335a20564b5c2998ef1555f0b5d41a69cf3d0c8405527e1`.

HTML contains 2,108 raw ID attributes, 407 resolved fragment links, 14,396
native MathML nodes, 134 semantic figures, and nine embedded PNGs. Browser QA
confirms a centered 1,152-pixel body at 1,440 × 900 and a 360/360-pixel body
and document at a 375 × 812 viewport with zero exposed overflow. PDF pages
398–424 were fully rendered and inspected; all 27 fonts are embedded/subset
with ToUnicode, nine primary images pair exactly with nine masks, and all three
clean builds are byte-identical. The PDF remains disclosed as untagged. The
append-only backend finishes at 6,113 records and replay passes. Next build
extends from Fomberg line 2847. GitHub commit
`465160690dcc3b8c92f0a7df2016027ee1b0d118`, Pages run `32854329469`, and
Zenodo DOI `10.5281/zenodo.22097007` preserve this boundary with exact
anonymous public-byte readback.

## Roberts 001–030 plus Fomberg 001–003 — prior boundary

Builder: `scripts/build-roberts-001-030-fomberg-001-003.ps1`. It freezes the
complete Roberts component and Fomberg `algebraic_topology.tex:31–1922`, builds
HTML and PDF twice from clean scratch, requires byte identity, and fails closed
on authority, source cursor, structure, links, MathML, figures, rights, privacy,
font, image, trailer-ID, or protected-prior-boundary drift.

- HTML: `output/html/roberts-001-030-fomberg-001-003/index.html`, 7,190,228
  bytes, SHA-256
  `484a2a501df79b1810567810d0b454a18298a4cb43ef466c4e082622216b9542`.
- PDF: `output/pdf/topologi-aljabar-roberts-001-030-fomberg-001-003-id.pdf`,
  3,550,987 bytes, 397 A4 pages, SHA-256
  `57382750a561667bf02eb98bd7f4806618c3a785f4ca18ceb4c6679c46543b4b`.
- Manifest: 286 bytes, SHA-256
  `eaadfc72151f617de4d316369be0bc70cd72006603d8853023206e8062f6e206`.
- Build receipt: `qa/ROBERTS_001_030_FOMBERG_001_003_BUILD_RECEIPT.json`,
  8,092 bytes, SHA-256
  `a164e36d1448808bc33f36b7685c92513313cc092c789f6876c9aa421c2b27ee`.

HTML contains 1,982 unique build-census IDs, 385 resolved fragment links,
13,466 native MathML nodes, 115 semantic figures, and six embedded Unit 003
PNGs. Browser QA confirms a centered 1,152-pixel body at 1440 × 900 and zero
page-level overflow at 375 × 812. PDF pages 377–397 were fully rendered and
inspected; all 27 fonts are embedded/subset with ToUnicode, six primary images
pair exactly with six masks, and the two clean outputs have no trailer ID and
are byte-identical. The PDF remains intentionally disclosed as untagged. The
release package and public GitHub/Pages and Zenodo byte readbacks pass. Next
build extends from Fomberg line 1923.

## Roberts 001–030 plus Fomberg 001–002 — prior boundary

Builder: `scripts/build-roberts-001-030-fomberg-001-002.ps1`. It binds the
complete Roberts component and Fomberg `algebraic_topology.tex:31–1290`, runs
two clean HTML builds and two clean PDF builds per invocation, and fails on
identity, source-cursor, link, MathML, accessibility, rights, or privacy drift.
The final QA invocation repeated this complete process, so four clean builds of
each reader were byte-identical.

- HTML: `output/html/roberts-001-030-fomberg-001-002/index.html`, 5,254,038
  bytes, SHA-256
  `1f7618003e3ff273a4f1e2d97b5a81fd320f76640c475cae845ed38793fbeccd`.
- PDF: `output/pdf/topologi-aljabar-roberts-001-030-fomberg-001-002-id.pdf`,
  2,399,760 bytes, 376 A4 pages, SHA-256
  `7dc8ac1db0b03ed1d9d94fe2c3491b631d3fb8bcec869997889d67d70236ef82`.
- Manifest: 286 bytes, SHA-256
  `f8d0d5444f443b731519f91e0eb51baee40d7954b9cf6560b8df391113dc45c2`.
- Receipt: `qa/ROBERTS_001_030_FOMBERG_001_002_BUILD_RECEIPT.json`, 7,955
  bytes, SHA-256
  `2339089281ebf3be33592cb484e7e0951a87ec66d458d8c278870202897f2f0c`.

HTML contains 1,849 unique IDs, 368 resolved fragments, 12,720 native MathML
nodes, and 89 semantic figures, with no runtime external asset, raw-TeX
fallback, duplicate ID, unresolved fragment, or exposed mobile page overflow.
The PDF embeds/subsets all 27 font records with ToUnicode; its untagged
limitation remains explicitly disclosed. Browser, every-new-page visual,
component-rights, package, and anonymous public-byte gates pass. Next build
extends from Fomberg line 1291; this boundary is immutable.

## Frozen upstream baseline

Input: exact `Notes.tex` at SHA-256 `cfe93e9dbe3e25bd96f711f59e6078ab97527682b58e1f8ad127f74357f665d7`.

Toolchain: MiKTeX 26.5, pdfTeX 1.40.29, LaTeX2e 2025-11-01. Two-pass builds used `SOURCE_DATE_EPOCH=1586154268` and `FORCE_SOURCE_DATE=1`. Two independent output directories produced byte-identical 119-page PDFs: 759,694 bytes, SHA-256 `933abb8920e4f8959d8c1b444b182d121efc860e7c0b8bdb32023974b1f51a76`.

Baseline caveats: 59 overfull boxes (six above 100 pt), two underfull boxes, 225 Tufte margin-note moves, untagged PDF, and no HTML/EPUB.

## Indonesian Unit 001

Canonical semantic source: `source/id-ID/reader-unit-001.md`.

Build command:

```powershell
pwsh -NoProfile -File scripts/build-unit-001.ps1
```

Pinned builder inputs:

- Pandoc 3.9.0.2
- MiKTeX pdfLaTeX
- `SOURCE_DATE_EPOCH=1787270400`
- `FORCE_SOURCE_DATE=1`
- MathML HTML with embedded CSS and no runtime JavaScript

The script builds the PDF twice, requires byte-identical SHA-256, removes its temporary duplicate PDFs, and writes `output/ARTIFACT_MANIFEST.csv`. HTML is the primary accessibility surface; the PDF is intentionally disclosed as untagged until a tagged-PDF toolchain is admitted.

Final Unit 001 artifacts:

- HTML: 85,580 bytes; SHA-256 `5cc4a29f2c29b274328b574d6698a51d75af0939f9959937db8d679c38ad51b8`.
- PDF: 321,743 bytes; 5 A4 pages; SHA-256 `6f71546a616c02ef81f8747ecfce3875784842065fc131cc82e5060b066a59c9`.
- Manifest: 228 bytes; SHA-256 `13772b2e2400923351225f422effe5f958e1dd8e178b9f6a32207682f791bcc3`.

Strict checks:

```powershell
python scripts/qa-unit-001.py
python scripts/validate-backend.py
```

The first command verifies the authority bytes, source span and structure, 29 stable IDs, exercise/solution closure, exact source correction, 259 MathML nodes, local fragments, offline/privacy properties, PDF metadata/text/fonts, and artifact manifest. The second validates the 139-record locale-neutral graph, canonical JSONL, every reference, source-span and artifact hash, rights separation, and exercise/solution relation. All 5 PDF pages were rendered at 120 dpi and inspected twice.

## Indonesian cumulative Units 001–002

Canonical semantic sources:

- `source/id-ID/reader-unit-001.md`: 16,179 bytes; SHA-256 `c80b51c22a2fa7ea116201028b78d5f8d708ef4d8355d34092ac7a9c88415e15`.
- `source/id-ID/units/unit-002-lecture-002.md`: 25,090 bytes; SHA-256 `4d2acc43557db9b3c419ee177545d285b9fcf50b2aa2dd3b2c6c44182f3a6a01`.

Build and QA:

```powershell
pwsh -NoProfile -File scripts/build-units-001-002.ps1
python scripts/qa-units-001-002.py
python scripts/validate-backend.py
```

The cumulative builder first requires the exact frozen Unit 1 source and artifacts, removes each unit's YAML header in a temporary assembly, adds one cumulative metadata header, and uses the same pinned Pandoc/MiKTeX/fixed-epoch toolchain. It writes only new cumulative artifacts, builds the PDF twice, requires byte identity, and removes its exact temporary assembly and duplicate PDFs.

Final cumulative artifacts:

- HTML: 220,035 bytes; SHA-256 `d3b5cbfaa3511823821ecf9ba26a4eaec7c84d937417927d11bde3f66abc9f54`.
- PDF: 395,385 bytes; 15 A4 pages; SHA-256 `0413c3a3280955cc482a5c0c2d7615b78128dccba3b6b1901dee1bf34d133b8e`.
- Manifest: 247 bytes; SHA-256 `93e98f6cbbc60775bb934df5b49141f63d7cd2c76582a26c61d4192ff320d721`.
- QA receipt: 2,690 bytes; SHA-256 `075546f6a856638dc420ed62b23ec78c7a57f839444e4f2101233d6421f776f0`.

Strict QA binds 70 stable IDs, 43 semantic blocks, all nine exercise–solution pairs, the Unit 2 question–answer pair, seven disclosed source corrections, 621 native MathML nodes, all fragments, offline/privacy properties, PDF metadata/text/fonts, and both cumulative manifest rows. All 15 physical PDF pages were rendered and manually inspected; the HTML was also checked in Chromium at 1280×720 and 390×844 for centering, reflow, local formula scrolling, and page-level overflow. P1/P2/P3 are zero. The frozen Unit 1 HTML and PDF remain byte-identical.

The cumulative locale-neutral backend contains 315 canonical records in 11 JSONL files and validates with bundle SHA-256 `f1999b5d33466ba9a15a32f50a16173fbb7659f1a7b28a3452bc5d2ec3094e6e`. It maps the exact union of all 70 stable IDs one-to-one to units and segments, closes all nine exercise–solution relations plus the Unit 2 question–answer relation, and binds every source, rights, correction, QA, and artifact reference.

## Indonesian cumulative Units 001-003

Canonical semantic sources:

- `source/id-ID/reader-unit-001.md`: 16,179 bytes; SHA-256 `c80b51c22a2fa7ea116201028b78d5f8d708ef4d8355d34092ac7a9c88415e15`.
- `source/id-ID/units/unit-002-lecture-002.md`: 25,090 bytes; SHA-256 `4d2acc43557db9b3c419ee177545d285b9fcf50b2aa2dd3b2c6c44182f3a6a01`.
- `source/id-ID/units/unit-003-lecture-003.md`: 25,822 bytes; SHA-256 `993e5941895a9b6f4b197b4c236f5a4990f6ae621e2bb7911353b28a5e1abffd`.

Build and QA:

```powershell
pwsh -NoProfile -File scripts/build-units-001-003.ps1
python scripts/qa-units-001-003.py
python scripts/validate-backend.py
```

The cumulative builder requires the exact frozen Unit 1, Units 1-2, all three source files, and embedded cumulative CSS before writing only the new Units 1-3 paths. It removes unit YAML headers in a temporary assembly, applies `SOURCE_DATE_EPOCH=1787356800`, builds the PDF twice, requires byte identity, and removes the exact temporary assembly and duplicate PDF.

Final cumulative artifacts and witnesses:

- HTML: 359,397 bytes; SHA-256 `33281cc46faa3d560c968b657526cd914786c991d1475b5563911a265bd316c1`.
- PDF: 460,320 bytes; 25 A4 pages; SHA-256 `2c9bf67e74c94bca9aad0238e910816188a957892a6cf811f7f615e221b4066d`.
- Manifest: 247 bytes; SHA-256 `1e211afb4b165435ece5f72a2b4e9b084975db35d111127880255473302f5049`.
- QA receipt: 3,983 bytes; SHA-256 `fb511086669846b6c8a68a6c1fecc4bd774016a6c95eb27219e3babbd177a873`.
- Extracted-text witness: 71,549 bytes; SHA-256 `2e8eabce2e0b8c3114b49d630187a6a0217e3ae90c466b5441f9eedccb299702`.
- Independent Unit 3 review: 2,464 bytes; SHA-256 `b2cffbcc2167c3d620f1af53224cc064e8ce34400561868339e69c280845619c`.
- Visual/browser receipt: 2,310 bytes; SHA-256 `4d7d603c2276bd570e3bf47897c67d98bf6507d2bd9ffed2acd10ab1a509130e`.

Strict QA binds 109 stable IDs, 68 semantic blocks, all 14 exercise-solution pairs, the Unit 2 question-answer pair, ten Unit 3 source corrections, four Unit 3 accessibility reflows, 1007 native MathML nodes, all fragments, offline/privacy properties, PDF metadata/text/fonts, and both cumulative manifest rows. All 25 physical PDF pages were rendered and inspected. The HTML was checked in the Codex in-app Chromium browser at 1280 x 720 and 390 x 844 for centering, reflow, formula-local scrolling, page-level overflow, fragment closure, and console errors. P1/P2/P3 are zero. Unit 1 and Units 1-2 artifacts remain byte-identical.

The cumulative locale-neutral backend contains 496 canonical records in 11 JSONL files and validates with bundle SHA-256 `0c08bebf7cbac289e94a7de571d3c2bab4d161c8a6a75c35b8a997f07ff6c939`. It maps the exact union of all 109 stable IDs one-to-one to units and segments, closes every exercise-solution and question-answer relation, records all 24 corrections/reflows, and binds every current source, rights, QA, and artifact reference.

## Indonesian cumulative Units 001-004

Canonical Unit 004 source:

- `source/id-ID/units/unit-004-lecture-004.md`: 24,582 bytes; 632 lines; 33 unique stable IDs; SHA-256 `826fcb368275cdad02f72a5cec951fc8466ba68b09ca0139d72c81a4c5591fea`.
- Exact authority span: frozen `Notes.tex:878-1131`; the Lecture 5 marker and proof of the terminal proposition begin at lines 1132-1134 and remain outside this boundary.

Build and QA:

```powershell
pwsh -NoProfile -File scripts/build-units-001-004.ps1
python scripts/qa-units-001-004.py
python scripts/validate-backend.py
```

The cumulative builder freezes every earlier source and public artifact, writes only the new Units 1-4 paths, uses Pandoc 3.9.0.2 with `SOURCE_DATE_EPOCH=1787356800`, and requires two PDF builds to be byte-identical.

Final cumulative artifacts and witnesses:

- HTML: 494,732 bytes; SHA-256 `8c8f5e1ad8172a2d97e3931fc3b4f2a3aa7f9e8a709260a27103f7eca0f1357d`.
- PDF: 539,006 bytes; 35 A4 pages; SHA-256 `5e92c4c6ed60bca9f2f4d362d4c48b4f01aa156b330e2adacd1bf88dd7de9e87`.
- Manifest: 247 bytes; SHA-256 `4c8bf407e426feb8db92308c4b28bdbbc0738416a85a13539ef7915e4c1aad83`.
- QA receipt: 4,478 bytes; SHA-256 `1670bbe2377712c9f96b9a68cdb75589ae461512f77cea7ad0c9290193724bd5`.
- Extracted-text witness: 100,684 bytes; SHA-256 `3d27bc1ab5a780bffce12d5951623b60929069238a210961740234502e71bf35`.
- Independent Unit 4 review: 3,031 bytes; SHA-256 `ac993a10e22738197775ae5c3f4e72948983c4e99ff602a52943b40ed417b6f9`.
- Visual/browser receipt: 2,257 bytes; SHA-256 `74e609e94ea47b89db223c21e12cae682048f0a60d8780dae96d5b0164f2c5ca`.

Strict QA binds 142 stable IDs and 88 fenced semantic blocks; all 18 exercise-solution pairs and both question-answer pairs; 18 Unit 4 source corrections/clarifications plus one accessibility reflow; 1,384 native MathML nodes; all 54 local fragments; offline/privacy properties; PDF metadata, fonts, text, and pages; and both manifest rows. All 35 PDF pages and the HTML at 1280 x 720 and 390 x 844 passed visual inspection. Fourteen wide phone-width formulas all scroll locally without widening the page. P1/P2/P3 are zero, and every earlier publication boundary remains byte-identical.

The cumulative locale-neutral backend contains 638 canonical records in 11 JSONL files and validates with bundle SHA-256 `590d28189a06cb46b47151de5359b245914a0a51f172e5e0cba6595f29712589`. It maps all 142 stable IDs one-to-one to units and segments, closes every exercise-solution and question-answer relation, binds all 53 adverse-ledger events, and registers the real cumulative artifacts and six passed Unit 4/cumulative QA events. Two deterministic generator reruns were byte-identical.

## Indonesian cumulative Units 001-005

Canonical Unit 005 source:

- `source/id-ID/units/unit-005-lecture-005.md`: 22,662 bytes; 663 lines; 30 unique stable IDs; SHA-256 `7333a7b7a92b9618016412abb5c9b2b2a398538f690d0109d4282289a0719852`.
- Exact authority span: frozen `Notes.tex:1132-1304`; the Lecture 6 marker begins at line 1305 and remains outside this reader boundary.

Build and QA:

```powershell
pwsh -NoProfile -File scripts/build-units-001-005.ps1
python scripts/qa-units-001-005.py
python scripts/validate-backend.py
```

The cumulative builder freezes all earlier sources and public artifacts, writes only the new Units 1-5 paths, uses Pandoc 3.9.0.2 with `SOURCE_DATE_EPOCH=1787356800`, and requires two PDF builds to be byte-identical. A cumulative-only 21 mm margin eliminates an otherwise isolated 45th-page continuation without changing any earlier builder or artifact.

Final cumulative artifacts and witnesses:

- HTML: 610,594 bytes; SHA-256 `8d3accf480101565409909c05f987f44b73f1c98889128e2f5074a4e049f48f3`.
- PDF: 589,065 bytes; 44 A4 pages; SHA-256 `d6929434a9bc7ae78fb71fc060e9cc54dce85d37e4997ffe042ccbab982e64e2`.
- Manifest: 247 bytes; SHA-256 `2910fd87871675730aea7ca33e636a70d330d0f81183e887bad74ea1fd2d5190`.
- QA receipt: 4,768 bytes; SHA-256 `ffb6703e4fe2ebc1c7733dc4f87a32c64c53cbe3ebf326d65a8d2da94765635a`.
- Extracted-text witness: 128,786 bytes; SHA-256 `83aca1060966c7ca7a7852630c27926754f0d893749aeb80888bbfd00f56a725`.
- Independent Unit 5 review: SHA-256 `399b81a06ac5701eca6604406c40acaa76f100291ee57f8efeb5344e7d7c8de0`.
- Visual/browser receipt: 2,877 bytes; SHA-256 `ed8249702d8335b01dc40925af1d5b071fa18d2eef9fe628a5535bd9404fbcdd`.

Strict QA binds 172 stable IDs, 106 fenced semantic blocks, all 22 exercise-solution pairs and both question-answer pairs, 16 Unit 5 source corrections plus one accessibility reflow, 1,659 native MathML nodes, all 66 fragment links, offline/privacy properties, PDF metadata/fonts/text/pages, and both manifest rows. All 44 PDF pages and HTML at 1280 x 720 and 390 x 844 passed visual inspection; 17 wide phone-width formulas scroll locally with zero page-level overflow. P1/P2/P3 are zero, and every earlier publication boundary remains byte-identical.

The cumulative locale-neutral backend contains 785 canonical records in 11 JSONL files and validates with bundle SHA-256 `c36095ba31dcdbc8db52e327902bfbfd419a65a3c827da41e847aa8dc55bc5e2`.

## Indonesian cumulative Units 001-007

Canonical added sources:

- `source/id-ID/units/unit-006-lecture-006.md`: 32,106 bytes; 893 lines; 28 unique stable IDs; SHA-256 `3cb182fdf183bd67e45a898228b995a44d4638e808fdfbe6ea6d6a2a2b889e33`.
- `source/id-ID/units/unit-007-lecture-007.md`: 22,107 bytes; 749 lines; 24 unique stable IDs; SHA-256 `556cea5445e1b0a51f86f1c0ea0e80c4e00a17d365d95fa530f063cc24856569`.
- Exact authority extension: frozen `Notes.tex:1305-1770`; line 1771 begins Lecture 8 and is outside this reader boundary.

Build and QA:

```powershell
pwsh -NoProfile -File scripts/build-units-001-007.ps1
python scripts/qa-units-001-007.py
python scripts/validate-backend.py
```

The cumulative builder freezes every Unit 1-5 source and artifact witness, assembles Units 1-7 with one metadata header, uses Pandoc 3.9.0.2 and MiKTeX pdfTeX 1.40.29 at `SOURCE_DATE_EPOCH=1787356800`, and requires two HTML builds and two PDF builds to be byte-identical. The PDF artifact operation was marked exactly once before creation.

Final cumulative artifacts and witnesses:

- HTML: 899,803 bytes; SHA-256 `55135048eafe0f097c45936add885e008392eefdf475270fea37adf6a2a7b7bb`.
- PDF: 702,470 bytes; 66 A4 pages; SHA-256 `3764b75ecfb9200e25a165db1f0f97a680384378e2a9a22e129aab57dd860d93`.
- Manifest: 247 bytes; SHA-256 `7b279f0413892f0ddedce636b3a272884bb7bfa01410bf33a6ce34c0c34db2f9`.
- QA receipt: 7,384 bytes; SHA-256 `2982a9465428eff97e6047bffdadba422b2dc0406e34750f632bfe148ed67617`.
- Extracted-text witness: 190,424 bytes; SHA-256 `f6839e7eb7f25c8518ec3fc2e2372b82b1f1387b48402899ff8bc40ce153c8dc`.
- Independent Unit 6 review: SHA-256 `5dd3868192a85e3e60562f42ec7d7b792e0e58811719ecc97207ed2bdc5de4bf`.
- Corrected independent Unit 7 review: SHA-256 `87c5129cd7d367893860b150c72948de1d196d7cbefe04d53f7a4efecf921f87`.
- Visual/browser receipt: 3,259 bytes; SHA-256 `63a4b4545213a7aec1c556a3852b818ba2f207b10cac7e80c62330709604176f`.

Strict QA binds 224 stable IDs, 135 fenced semantic blocks, all 30 exercise-solution pairs and both question-answer pairs, all 24 Unit 6-7 correction records, 2,344 native MathML nodes, all 89 fragment links, the preserved `eg:piS^1_infinite` source alias, offline/privacy properties, and PDF metadata/fonts/text/pages. All 66 PDF pages were rendered and inspected; pages 1, 45, 57, and 66 were also inspected full-size. HTML passed at 1280 x 720 with a centered 928 px body and at 390 x 844 with zero page overflow and 32 formula-local scrollers. P1/P2/P3 are zero, and every earlier boundary remains byte-identical.

The cumulative locale-neutral backend contains 995 canonical records in 11 JSONL files and validates with bundle SHA-256 `0acf007e732682268d904699b4fbcf12c5f1a757b98938b776a72614b432df64`.

## Indonesian cumulative Units 001-010

Canonical added sources:

- `source/id-ID/units/unit-008-lecture-008.md`: 28,466 bytes; 930 lines; 26 unique stable IDs; SHA-256 `8369e74c80e391d73575bbcb7844d3bfa62dd771dbca6258eed02360b20529cc`.
- `source/id-ID/units/unit-009-lecture-009.md`: 25,524 bytes; 939 lines; 30 unique stable IDs; SHA-256 `16da25dea2f8ac5415b02738663046fb619c27e685042a734059e3150ed5ff18`.
- `source/id-ID/units/unit-010-lecture-010.md`: 26,432 bytes; 934 lines; 26 unique stable IDs; SHA-256 `e1c6ef961ae2266db86baec6d701dd659a1bf78bdd3601cf5b1c6515bc7d0310`.
- Exact authority extension: frozen `Notes.tex:1771-2272`; line 2273 begins Lecture 11 and is outside this reader boundary.

Build and QA:

```powershell
pwsh -NoProfile -File scripts/build-units-001-010.ps1
python scripts/qa-units-001-010.py
python scripts/validate-backend.py
```

The cumulative builder freezes every Unit 1-7 source and artifact witness, assembles Units 1-10 with one metadata header, uses Pandoc 3.9.0.2 and MiKTeX pdfTeX 1.40.29 at `SOURCE_DATE_EPOCH=1787356800`, and requires two HTML builds and two PDF builds to be byte-identical. A PDF-only `\sslash` compatibility shim supports the cumulative toolchain without changing any source unit. The PDF artifact operation was marked exactly once before creation.

Final cumulative artifacts and witnesses:

- HTML: 1,318,415 bytes; SHA-256 `e228ac1422b2742d873feffd5b236fe9c1329d0bdb5da0e8deffe5e770361088`.
- PDF: 862,913 bytes; 99 A4 pages; SHA-256 `d0f739aedf3da5f317cf99a1a0dcace1f89b8c802f1dedc42c7ac0c63375c7c1`.
- Manifest: 248 bytes; SHA-256 `5bcf82984e3f2848f5471876401e48948639d6ca144e0915d99c86c20fc39d92`.
- QA receipt: 9,808 bytes; SHA-256 `4189663021e6bd7e8822198a79bb3d7c59c7e0cca777054fbc370e77a300da5c`.
- Extracted-text witness: 280,664 bytes; SHA-256 `4932889b582a3ccd9816db4b8008791d5fbdc4b044da6f5d1985a87b6ce10642`.
- Visual/browser receipt: 2,471 bytes; SHA-256 `439099f8c865125864444f9cfd1f60b961274ba0bc6f9bb29c562ee30fab132b`.

Strict QA binds 306 unique stable IDs, 183 semantic blocks, all 45 exercise-solution pairs and both question-answer pairs, the complete Unit 8-10 correction/reflow ledger, 3,411 native MathML nodes, all 123 fragment links, five retained source-label aliases, offline/privacy properties, PDF metadata/fonts/text/pages, and both manifest rows. Both validators pass independently. All 99 PDF pages were rendered and inspected, with full-size checks at the Unit 8-10 boundaries and final page. HTML passed at 1280 x 720 with a centered 928 px body and at 390 x 844 with zero page overflow and 37/37 formula-local scrollers; browser warnings/errors are zero. P1/P2/P3 are zero, and every earlier boundary remains byte-identical.

The cumulative locale-neutral backend contains 1,345 canonical records in 11 JSONL files, totaling 1,131,189 bytes, and validates with bundle SHA-256 `ca6ff5b776594f5b3c1408accfc6129b876fbcdc6d029279dbbbbc1d9a40bbdf`.

## Indonesian cumulative Units 001-013

Canonical added sources:

- Unit 011: `Notes.tex:2273-2494`; 28,465 bytes; SHA-256 `1cdbe0cae239a4e60a72f25c8814c2e3b5ec26b9119da03624bda7f3ff1ae127`.
- Unit 012: `Notes.tex:2495-2726`; 32,850 bytes; SHA-256 `429831df4a5600c59351516915fb787cd73402d8c11c411869210dbf8aaa7ada`.
- Unit 013: `Notes.tex:2727-3046`; 41,196 bytes; SHA-256 `0aa68cb4ed31862d32aeff5a7106b4ac29c13cbc202f7dbc8381fc7cd31418c0`.
- Exact cumulative authority span: frozen `Notes.tex:134-3046`; line 3047 begins Lecture 14 and is outside this reader boundary.

Build, backend extension, and QA:

```powershell
pwsh -NoProfile -File scripts/build-units-001-013.ps1
python scripts/extend-backend-units-011-013.py
python scripts/validate-backend.py
python scripts/qa-units-001-013.py
```

The builder uses Pandoc 3.9.0.2, MiKTeX pdfTeX 1.40.29, and fixed `SOURCE_DATE_EPOCH=1787356800`. Two HTML builds and two PDF builds must be byte-identical before the final artifacts are copied. During final recovery QA the already marked PDF was not rebuilt and its marker was not rerun; the builder's original two-build fail-closed evidence and bytes remained frozen.

Final cumulative artifacts and witnesses:

- HTML: 1,824,804 bytes; SHA-256 `be1473ab5cb8eff26341e554179661775a12cec5784a8ebf3f9c2f3f0633cb71`.
- PDF: 1,071,382 bytes; 138 A4 pages; SHA-256 `14775535f773735db5886195980f39e417aaea24998927956a81b55b0ef77c68`.
- Artifact manifest: 249 bytes; SHA-256 `6b55446a4f0a951329c29ec33b0ca586c749b9301dd4bd8ad4dd94f1c91d74de`.
- QA receipt: 9,069 bytes; SHA-256 `cb2413e8131743457a0685a57cf519c769e5593e9ec8d904f6160f9e0519983d`.
- Visual/browser receipt: 2,139 bytes; SHA-256 `78e151b05d3efdce4dbfd346962dece5d7da4a559ab1101ac4bd8e02bff59f48`.
- Render inventory: 16,336 bytes; SHA-256 `71168ca32a0be0828c5d8b0b94328410c1f842913d4aab0ad833b4315bffd4ef`.
- Extracted-text witness: 395,766 bytes; SHA-256 `d94869df978e2538c79b8859cb38c8cbf859420cde68326a35546c973c787497`.

Strict QA binds 426 stable IDs, 261 semantic blocks, 587 unique artifact IDs, eight aliases, all 160 local fragment links, 4,682 native MathML nodes, and the complete prompt-solution closure. HTML is self-contained, centered at a 928 px desktop body, has zero document overflow at 390 x 844, and gives all 54 wide mobile formulas local scrolling. Browser warnings/errors are zero.

The PDF is unencrypted, uses A4, carries `id-ID`, has 24/24 fonts embedded, subset, and mapped through ToUnicode, and yields 269,310 extracted characters. It remains intentionally untagged, so semantic HTML is the primary accessibility surface. Fresh Poppler renders of all 138 pages and desktop/mobile browser inspection found no clipping, overlap, broken glyph, unintended blank page, or black box.

The cumulative locale-neutral backend contains 1,762 canonical records across 11 JSONL files, totaling 1,540,725 bytes. The extension is idempotent, both the extension and independent root rerun validate, and the validator-defined bundle SHA-256 is `bb8512f56a8bbcf1283ae10ab69a9a7ecebb1bd39c425c1c021b5b848a1b2910`.

## Roberts 001-030, Fomberg 001-007, and Cumulative Assessment 1

Canonical added source:

- `source/id-ID/mastery/cumulative-assessment-001-foundations-coverings-homotopy.md`: 15,185 bytes; 389 LF lines; 34 stable IDs; SHA-256 `5888df0410ad7e8ccf50d8ea8092e43a42f6df94c242f7c09abe0616d972e6f8`.
- The original CC BY-SA 4.0 layer contains exactly eight exercises, eight hints, and eight complete checked solutions, mapped across `D60-R01`-`D60-R07`. It does not copy or adapt the excluded Fomberg problem bank.

Build and QA:

```powershell
python -B scripts/qa-cumulative-assessment-001.py
python -B scripts/validate-backend-append-only-cumulative-assessment-001.py
python -B scripts/census-route-mastery.py
pwsh -NoProfile -File scripts/build-roberts-001-030-fomberg-001-007-ca01.ps1
```

The append-only backend preserves the exact 6,742-record Unit 007 prefix and
adds 112 records. The result has 6,854 records, 8,345,799 bytes, and bundle
SHA-256 `51e75d06e620762e629e9e7408da4b0c32b3e337817d9d140fbbdfa438de2f57`.
The cumulative receipt is
`qa/BACKEND_APPEND_ONLY_CUMULATIVE_ASSESSMENT_001_CUMULATIVE_RECEIPT.json`,
9,934 bytes, SHA-256
`79fc0c7afde5f72b9eaf3809b08ab27cfd696c9d0269905608a1336ae4cd7e13`.

Final cumulative artifacts and witnesses:

- HTML: 14,958,219 bytes; SHA-256 `d71e2f3c0eb38b48fe4686a955ad555db3a407df8f18e41371d52908f0bdbbdf`.
- PDF: 8,358,561 bytes; 477 A4 pages; SHA-256 `476b0de3bbb2cbfe03a151ac3060e121c5f89364e70b54d918ab270f4c965ade`.
- Artifact manifest: 297 bytes; SHA-256 `eac46f939ac99da1479c7826a350eb926c30f91d4c74fdfe785a597f7a58803d`.
- Final build receipt: 7,842 bytes; SHA-256 `22fef828b7963219759f85d11e409e0ebf957889d0fa76dc02ec04f3a707a9e0`.
- Visual QA: 5,161 bytes; SHA-256 `c33d75b9f93224ece7e57bcb7aae9413f47a84f3eade72fbd010c09463182e2a`.
- Browser QA: 2,358 bytes; SHA-256 `3558f726ed794f4e94729a86e7177b407dc1efabf668b96a76f80d68ca3acca4`.

Two HTML fragments, two standalone CA01 PDFs, and two cumulative PDFs are
byte-identical at their respective deterministic gates. All 472 predecessor
PDF pages preserve their visual/content signatures and extracted text. All
389 outline entries and all 2,873 named destinations resolve; the 379-entry
predecessor outline is an exact title/page prefix and the ten new CA01 targets
resolve to physical pages 473-477. Pages 472-477 were rendered at 150 dpi and
inspected at full detail with P1/P2/P3 all zero. The self-contained native-MathML
HTML is centered at desktop width and reflows at 375 x 812 with no page-level
horizontal overflow, no broken fragments, no external runtime asset references,
and zero console errors. The PDF remains intentionally untagged; HTML is the
primary accessibility surface.

The checkpoint is public at GitHub content commit
`4b5f8f74bf361e45687d55fc31a95ea3e0c657ab` and Pages run `32924728855`;
the Pages reader and twelve commit-pinned witnesses match local bytes under
anonymous HTTP readback. Zenodo version `0.31.0`, record `22105179`, DOI
`10.5281/zenodo.22105179`, reuses concept DOI
`10.5281/zenodo.22061489`; its exact nine-file, 31,542,547-byte payload passed
anonymous byte/SHA-256 readback for every file.

## Roberts 001-030, Fomberg 001-007, CA01, and ordinary hints R01-R06

Canonical additive source:

- `source/id-ID/mastery/ordinary-hints-r01-r06.md`: 28,698 bytes; 410 LF
  lines; 36 hint blocks; 43 stable IDs; SHA-256
  `dc319cb191d709a5807f0c0792401f9faf2993ceede364764547f20bb4f69c2a`.
- Every hint binds one exact existing exercise to one exact existing complete
  solution across `D60-R01`-`R06`; no prompt, solution, or solve edge changed.
  The layer is original CC BY-SA 4.0 material and does not use the excluded
  Fomberg problem bank.

Build and QA:

```powershell
python -B scripts/qa-ordinary-hints-r01-r06.py
python -B scripts/validate-backend-append-only-ordinary-hints-r01-r06.py
python -B scripts/census-route-mastery.py
pwsh -NoProfile -File scripts/build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06.ps1
```

Append-only replay preserves the exact CA01 prefix at 6,854 records and
8,345,799 bytes, adds 158 records, and ends at 7,012 records/8,545,732 bytes
with bundle SHA-256
`7d723f9ef163303c7dde63d646dc8d5917c2450b1da5d24c87ef77bf4e4d664b`.
Its cumulative receipt is 10,252 bytes/SHA-256
`10e9d32848b950148983d0d8c38d6753a9956a674f657858b31dd257af5b2aa8`.
The route census is 84/84 ordinary items plus CA01 8/8, hence 92/108 total;
CA02 and CA03 contain the remaining 16 items. Duplicate/reused solution IDs
and validation errors are both zero.

Final cumulative artifacts and witnesses:

- HTML: 15,026,881 bytes; SHA-256
  `7ed278d73a324ba0a9e5acadedf448221b3791db7322fdf6d29225afd0124d2b`.
- PDF: 8,592,243 bytes; 482 A4 pages; SHA-256
  `4da7f1368c17423cd6845c36b7d5190dac98d515ecbd32467c0c59961dd9afcb`.
- Artifact manifest: 325 bytes; SHA-256
  `2273669b06917c09e8c909f8bb51ab6518e0572c2f7c9f74e1b647013268dc3a`.
- Final build receipt: 8,674 bytes; SHA-256
  `e0192345c0a5bf75c508edb005c95e712ef6c70630e368feab01fcb7f9e0ce76`.
- Static hint QA: 16,616 bytes; SHA-256
  `a0460dbed83242863fc1aab8290b76fac9cd39644276e132401e7d3e9198c33d`.
- Independent math review: 19,289 bytes; SHA-256
  `8ed5b3563976b415e1aa471f7cdeb3405888cbc70aec101bc02e4fab9e45de5a`.
- Independent source-language review: 18,324 bytes; SHA-256
  `6c29009da4ee0380c878c3705dcd2a99cbe7a8495cc4b7f5ce456bb40f910968`.
- Visual QA: 5,341 bytes; SHA-256
  `fce44f8ef46c6bbc2ed8ef09f1c04072ebb8ee56033af98e7c8431e920d73afd`.
- Browser QA: 4,483 bytes; SHA-256
  `e42eb5965a3568f94d8ff01f9d65578283dd71016e3d11f8fcb9b1f905141a23`.

Two clean final builds are byte-identical. The 477-page predecessor is
preserved exactly, five hint pages are appended, all 396 outline entries and
2,988 named destinations resolve, and all 72 visible predecessor links pass
structural and independent target-page checks. Pages 477-482 pass rendered
visual inspection. The self-contained native-MathML HTML has zero unresolved
fragments, no external runtime assets, centered desktop layout, mobile reflow
without page-level overflow, keyboard focus, AA contrast, and zero browser
errors or warnings. The PDF remains intentionally untagged; HTML is the
primary accessible surface. The boundary is public at GitHub commit
`646769fb52a51e997f5409fc2148f8892508da1d` and Pages run `32933679761`;
all 58 commit-delta paths and the deployed reader match anonymous bytes.
Zenodo version `0.31.1`, record `22106133`, DOI
`10.5281/zenodo.22106133`, preserves concept `10.5281/zenodo.22061489`; all
nine reader-first files passed two complete anonymous byte/SHA-256 readbacks.

## Roberts 001-030, Fomberg 001-007, mastery 108/108, and computation Lab 1 — current boundary

Canonical additive source and executable closure:

- Reader: `source/id-ID/labs/computation-lab-001-monodromy-presentations.md`,
  12,275 bytes, 397 LF lines, SHA-256
  `165e2f9ba587714fb32a2f5a6432920a36493ebc6902d580f55df9c8ab4c65c4`.
- Program: `source/id-ID/labs/o012_d60_lab01_monodromy.py`, 8,818 bytes,
  SHA-256 `a9c8875aeb2642921a2d152cd0ed316c6c67969a466240ada9836d3c42252628`.
- Tests: `source/id-ID/labs/test_o012_d60_lab01_monodromy.py`, 3,032 bytes,
  SHA-256 `ae30ca6604b2a96b12c7df125fdcaa6deea00a9e4594f6b161d7d4785d9b949b`.
- Expected output: `source/id-ID/labs/expected-output-lab01.txt`, 478 bytes,
  SHA-256 `ddaa8015f314e53895c311e12be4d2d1dcaa1fa3f20def4ee112f28077a38717`.

Both program runs are byte-identical and match the expected output; both test
runs pass 6/6. Independent mathematics and source-language reviews pass with
P1/P2/P3 zero. Aggregate QA is 4,258 bytes/SHA-256
`75dede0eaa0edbb22c75470dc641bdd10f95aac57c05331171ace4ac9e68aa2b`.

Build and QA:

```powershell
python -B scripts/qa-computation-lab-001.py
python -B scripts/validate-backend-append-only-computation-lab-001.py
python -B scripts/build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03-lab01.py
python -B scripts/finalize-build-roberts-001-030-fomberg-001-007-ca01-hints-r01-r06-ca02-ca03-lab01.py
```

Append-only replay preserves the exact 7,273-record/8,840,132-byte predecessor,
adds 131 records/135,568 bytes, and ends at 7,404 records/8,975,700 bytes with
bundle SHA-256
`4740eb2ff83b4f9df3c0d90c2426ff77e652b23cad0bbe7763c54ebdefa60b4b`.
Its cumulative receipt is 9,727 bytes/SHA-256
`90f445294eea58aca5bcebe6acaff7293251b21e32aa25f3b62705e64cf8ab74`.

Final cumulative artifacts and witnesses:

- HTML: 15,389,821 bytes; SHA-256
  `bb0cf484271370878508a6b774e442ee57aaf82b1a3bbca1bed086729360f7ff`.
- PDF: 9,193,942 bytes; 511 A4 pages; SHA-256
  `722fa7f6c3aa20d1a4c52257d3127fa500bbaf6aad66f64d62177718cd53d128`.
- Artifact manifest: 357 bytes; SHA-256
  `cbb39a0f0a7b4831fa5eaa2e9b3beb6fc5fa15379ec322f2abb8279fa2b7d824`.
- Final build receipt: 6,798 bytes; SHA-256
  `820019c2592c8af11d41a02215b4fb5805368760d926ecb06d4760f4dccf9106`.
- Visual QA: 3,224 bytes; SHA-256
  `7030f5129208c978a1dc51947bcea916b25751e988abd9a73925cbfcb0c79206`.
- Browser QA: 2,979 bytes; SHA-256
  `3a80c7eb7f2b0db70622e0b9785e61ee34763d514add6c92c0d7728e0caad901`.

Two clean HTML, appendix-PDF, and merged-PDF builds are byte-identical. The
501-page predecessor is preserved by exact extracted-text prefix and page-
structure evidence. All 24 new destinations and 17 new outline entries resolve;
all fonts are embedded, subset, and ToUnicode-mapped. Physical pages 501–511
pass original-detail visual inspection. The HTML is self-contained, centered
at 1,152 desktop pixels, reflows at 375 × 812 with zero page-level overflow,
gives all four wide code blocks local mobile scrolling, resolves all 846
fragment links, exposes keyboard focus, and logs zero browser errors or
warnings. The PDF remains untagged; HTML is the primary accessible surface.
Zenodo version `0.31.3`, record `22142210`, DOI
`10.5281/zenodo.22142210`, now preserves the reader-first nine-file package in
the existing concept `10.5281/zenodo.22061489`. Every file passed two anonymous
HTTP 200 byte/SHA-256 readback passes. Sanitized publication receipt SHA-256 is
`ef52c6362b65424c79991ffd35ede64b0ed64d96a0219577fe0df1016b25f830`.
GitHub content commit `a8311697800102ce65ce7f67752b0179ccaa9109`, tree
`4f438d7932f3576ae78be051ca210b5914e1eb30`, Pages run `33162255086`, job
`98819266824`, deployment `6139369092`, and successful status `17454891852`
pass. All 69 changed files/66,866,333 bytes match their commit-pinned public
copies; raw and Pages reader bytes match the local HTML exactly, and the frozen
predecessor remains exact. Delta-manifest SHA-256 is
`7a080f8120e58f8c7fd39bd56247d993c03095bd900c329303471119d17e435b`.
Sanitized GitHub receipt is 30,246 bytes/SHA-256
`bf9bb396135010ccdfe6ec950b46d84ec59eb6ddfc1c9624a841341fe15086bc`.

## Roberts 001-030, Fomberg 001-007, mastery 108/108, and computation Labs 1–2 — current boundary

Laboratory 2 adds an original CC BY-SA 4.0 reader, offline standard-library
program, six deterministic tests, frozen output, hint, and complete solution
for simpleksial boundary matrices and Smith normal form. Source/execution/
review QA is 4,318 bytes/SHA-256
`c084e575a621906ac7d8a1c6dca6f604de99b8e58a788409be17bb7392dd4319`;
independent code, mathematics, and source-language reviews pass P1=P2=P3=0.

Append-only replay preserves the exact 7,404-record/8,975,700-byte Lab 1
prefix, adds 142 records/147,055 bytes, and ends at 7,546 records/9,122,755
bytes with bundle SHA-256
`ac3a0377861ed2b728f9c7473579fdd4febe43e454a92f3ea06451e13d46c8f8`.
The cumulative receipt is 10,039 bytes/SHA-256
`8c37c03b59ba638bb7c9533f4078cd75b5500bfaa408e8b816a5bef1b5bc522b`.

Final cumulative artifacts and witnesses:

- HTML: 15,615,104 bytes; SHA-256
  `d0c6afddfa92759d475258bf08f20ea4019eccf72b7554128b2b938bd247b375`.
- PDF: 9,507,127 bytes; 529 A4 pages; SHA-256
  `1bad03f9ba031ba91967a0a0ac2af6d15a0f768882cd541fe26dcbe26c4edd0b`.
- Artifact manifest: 369 bytes; SHA-256
  `11d45714eddfecfc63a6d660f1dedac99a3ecf3d5fb36dc19961e34fb26c137c`.
- Final build receipt: 7,468 bytes; SHA-256
  `d7e224f936cd9dcfe2238038730d9a89d78fe59b2933a8623c6df34121f48b98`.
- Visual QA: 3,450 bytes; SHA-256
  `49bb2e287e1b2ad2bfd7a1814a7234a7bc5398ae35deab770f66e101d36271d8`.
- Browser QA: 3,574 bytes; SHA-256
  `91ceb3c55c1e0de1448af839b56bbcdb257c8fbf79ccfe7e1c72a5743157974a`.

Two clean HTML, appendix-PDF, and merged-PDF builds are byte-identical. The
511-page predecessor is structurally and textually preserved. All 19 bounded
pages pass full-detail visual QA; HTML passes centered desktop and 375 × 812
mobile reflow with zero page-level overflow, zero unresolved fragments, zero
external runtime assets, and zero console errors/warnings. Zenodo version
`0.31.4`, record `22147224`, DOI `10.5281/zenodo.22147224`, is public in the
unchanged concept `10.5281/zenodo.22061489`; every one of the reader-first nine
files passed two anonymous byte/SHA-256 readback passes. Sanitized receipt is
11,568 bytes/SHA-256
`3fbc40c68fac53010fd6248ccb5438e2ffc7ab1a56c7ac390996b50b6ba35b95`.
GitHub content commit `8989fbd602f89d0a8d6c30bc7bac1980a74b2c99`, tree
`064aa78a25fcc34aaa0a1e8e64d52b2a702c79d7`, and Pages run `33187541456`
preserve the same Lab 2 boundary. The deployment succeeded at ID `6144286315`
with status ID `17467474103`. All 71 changed files (68,293,528 bytes) passed
anonymous commit-pinned raw byte/SHA-256 readback; both the deployed current
reader and frozen Lab 1 predecessor passed exact Pages/raw comparison. Sanitized
GitHub receipt is 31,229 bytes/SHA-256
`c6ccde700267a29dfb2246cb4f5a78428547c75709ac60a56c9a222c84865a80`.
## Roberts 001-030, Fomberg 001-007, mastery 108/108, and computation Labs 1–3 — public boundary

Laboratory 3 adds the original CC BY-SA 4.0 cellular-boundary/degree reader,
standard-library program, six deterministic tests, frozen expected output,
interpretation, hint, and complete solutions. Independent code, mathematics,
and source-language reviews close at P1=P2=P3=0. Append-only admission
preserves the exact 7,546-record Lab 2 prefix, adds 148 records/157,630 bytes,
and ends at 7,694 records/9,280,385 bytes with bundle SHA-256
`cddd65499da547e0c4f01b8a880f68d1c3d314c078a9179528e4a28b2c5f65a2`.

The centered/reflowing HTML is 15,828,588 bytes/SHA-256
`c221955503cec820c7581c740a038ac1774999ac6a6014f8d0783da2cd08bf0d`;
the deterministic PDF is 9,836,725 bytes/545 A4 pages/SHA-256
`b26b670db97facc9f5ab389eed69cf1f8b03f70e6047eacbd2bfa68c849ccd0d`.
Two clean builds match byte-for-byte. Physical pages 529–545 pass original-
detail visual inspection, and desktop/mobile browser QA passes centered
reflow, local wide-content scrolling, fragments, navigation, keyboard focus,
offline assets, and console checks. Final build receipt SHA-256 is
`18cbb0558a08cee737e375351a4f3f7fb7b65c0e29672b22851612a8a58d1eab`.

Zenodo version `0.31.5`, record `22151513`, DOI
`10.5281/zenodo.22151513`, is public in concept `10.5281/zenodo.22061489`;
all nine files passed two anonymous exact readbacks. GitHub content commit
`2196b7cb998b66c50a182a1312dcca7ddba29ccf`, tree
`27a6ef284579d2dcd1817077b5c4351acff0a38f`, Pages run `33223430957`, job
`99022162212`, deployment `6150632335`, and status `17485382930` pass. The
strict verifier matched all 70 explicit changed paths, all eleven backend
files, the deployed reader, its Lab 2 predecessor, and Zenodo's public
nine-file inventory. Sanitized GitHub receipt is 56,936 bytes/SHA-256
`145f085aa531d198deff47b50f3a35f809fada62051fe26e7ee4c8dfc6558dcd`.

## Computation Laboratory 4 — first coherent source/executable boundary

The current frozen learner files are:

- reader: 15,716 bytes/388 LF/SHA-256
  `5e4d7bd4402d7ad0bd4be031c239ef2f7c223942431d800fee823b64fde327f4`;
- program: 13,392 bytes/353 LF/SHA-256
  `63a874df2dff8ee2a6c4a7528e5195916744e0efb93f15972208d0e82609230b`;
- tests: 7,204 bytes/164 LF/SHA-256
  `5be88132683cc23980e129d3b8ee4e4930e84d1c0e65afc91ca301377a997031`;
- expected output: 609 bytes/12 LF/SHA-256
  `d92d0988c3aea1b79faba84a1302d6acf4854dadfa22d6ea616248ede362bf17`.

The six tests and program output pass repeatedly; static QA is 3,580 bytes/
SHA-256 `68aa02e2830539c21167c106752747d7d85964a8ee82e4d56689c167c2385786`.
Clean independent review, backend admission, and cumulative reader build are
the next gates; no Lab 4 build or publication is claimed here.

## Computation Laboratory 4 — independent source/execution gate closed

All three clean independent reviews now pass with P1/P2/P3 zero and bind the
same frozen reader, program, tests, expected output, and static QA identities:

- independent code review: 4,839 bytes/153 LF/SHA-256
  `a841e03d2cb71dbeba55b684d2463d91407275ba8549adc97501a193d0862baa`;
- independent mathematics review: 6,972 bytes/179 LF/SHA-256
  `8aae9b1da8dc639e60a80393025fcb713a7892c6618c7b0706a8e5b70758e89b`;
- independent source-language review: 4,628 bytes/126 LF/SHA-256
  `7affc837eee816c677f3fc93682b82afb151acaef217a0a2ddfece8166c8eaf1`;
- exact execution receipt: 1,999 bytes/68 LF/SHA-256
  `cbe2d26e63b580b0ec390ea66dcbfb48fdc932df3deec78d4c92051746955b88`;
- combined QA receipt: 4,668 bytes/169 LF/SHA-256
  `c021dc617a9d015c1f6b6a5e4a4695822e9b5ce89e44c1b60808d0e6ac300712`.

The six-test suite and command-line program were independently repeated, the
609-byte expected output matched exactly with empty stderr, adversarial inputs
were rejected, and the mathematics/ring-law checks passed. Append-only backend
admission against the exact 7,694-record Lab 3 prefix is now the live gate; no
Lab 4 reader-build or publication claim is made at this source-only boundary.

## Computation Laboratory 4 — append-only backend admitted

The isolated producer ran twice and matched all 13 candidate files byte for
byte. Independent semantic validation and resume-safe live replay pass. The
exact Lab 3 prefix remains 7,694 records/9,280,385 bytes with bundle SHA-256
`cddd65499da547e0c4f01b8a880f68d1c3d314c078a9179528e4a28b2c5f65a2`.
Lab 4 adds 153 records/162,865 bytes with delta bundle SHA-256
`256a8333f7d1ba49086166560ed1200b4834a8914631d1cb8a094f30891dd48e`.
The live cumulative backend is 7,847 records/9,443,250 bytes with bundle
SHA-256 `2633732fd2fd2b5fb8afb5888b1864b6bcda9dca52eb85a6636c777ac1018c1f`.

The suffix census is 10 artifacts, 12 concepts, seven QA events, 61 relations,
one rights record, 25 segments, 12 terms, and 25 units. It binds all 25 reader
IDs, six tasks, the shared hint/full-solution surface, five route mappings, and
17 verified prerequisite edges. The independent cumulative receipt is 12,455
bytes/SHA-256 `2364c6e3e518605f41f3b2083adacc4016e5c5f7accdc606430a08aa0f8564a1`;
the atomic finalization receipt is 2,099 bytes/SHA-256
`6663925df8f10a3fe0c95e21e91c6eaf58e593b56d06e52b5a169ccfd1ce2827`.
All four required laboratories are now admitted. The cumulative four-lab
reader build and visual/browser QA are next; no publication claim is made here.

## Computation Laboratories 1–4 — final local reader boundary

The fail-closed finalizer independently revalidated the Lab 4 source/execution
QA, exact append-only backend replay, deterministic build draft, final HTML and
PDF identities, bounded Poppler render inventory, desktop/mobile browser
receipt, rights, privacy, and predecessor preservation. The final receipt is
`qa/ROBERTS_001_030_FOMBERG_001_007_CA01_HINTS_R01_R06_CA02_CA03_LAB01_LAB02_LAB03_LAB04_BUILD_RECEIPT.json`,
8,255 bytes/239 LF lines/SHA-256
`21e62297589346d3fbf5cf4a91f0a322d46e059c4a86f585556a942053190fa9`.

Final cumulative artifacts:

- HTML: 15,974,648 bytes; SHA-256
  `a76e31fc92e1554a6b14ffaccc1ad1001ee5c2838a3e36d1441b98519b39d4f8`.
- PDF: 10,131,344 bytes; 558 A4 pages; SHA-256
  `337dcb8bf7ee3d5b5b58c0efc621e661db2542b49f52f1b12b786b55db4fa2fc`.
- Artifact manifest: 394 bytes; SHA-256
  `2ae57ef9dfba517586cb983ed3fb94942e0e418ae36680f147d427acb3101c81`.
- Visual QA: 3,622 bytes; SHA-256
  `c3ad953547446ee23574a0b0f90dfd6958384d5caea9087ec83f3adf6bbea1ea`.
- Browser QA: 3,722 bytes; SHA-256
  `0f24144742334477e8f2662d7a79fab7a19e4542bf6d26884f282d3b97a40209`.

Two clean final builds are byte-identical. The 545-page predecessor remains
structurally and textually preserved; 13 Lab 4 pages are appended. All 14
transition/new pages pass original-detail visual inspection. All 487 outline
entries and 3,155 named destinations resolve. HTML is self-contained and
centered, reflows without document overflow at 375 x 812, gives each wide code
or formula a local scroller, resolves all 2,766 fragments, exposes 17,487
native MathML nodes, and has zero external runtime assets or browser console
errors/warnings. The PDF remains intentionally untagged; HTML is the primary
accessible surface. This is a local verified boundary only until the existing
GitHub/Pages and Zenodo lineages pass anonymous public-byte readback.
